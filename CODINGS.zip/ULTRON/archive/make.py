import csv

def tsv_to_csv(input_file, output_file):
    with open(input_file, 'r', newline='') as tsv_file:
        tsv_reader = csv.reader(tsv_file, delimiter='\t')
        with open(output_file, 'w', newline='') as csv_file:
            csv_writer = csv.writer(csv_file)
            for row in tsv_reader:
                csv_writer.writerow(row)

# Specify input and output file paths
input_tsv_file = 'dialogs.txt'  # Update with your TSV file path
output_csv_file = 'output.csv'  # Update with desired CSV file path

# Convert TSV to CSV
tsv_to_csv(input_tsv_file, output_csv_file)
