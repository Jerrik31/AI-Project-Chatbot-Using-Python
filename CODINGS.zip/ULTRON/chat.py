import csv
from flask import Flask, request, render_template
import difflib

app = Flask(__name__)
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

# Read destinations from CSV
destinations = {}
with open('output.csv', 'r', newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        destinations[row['Question'].lower()] = row['Answer']

def find_approximate_match(user_input):
    # Tokenize and normalize the user input
    user_tokens = [word.strip().lower() for word in user_input.split()]

    # Initialize variables for the best match
    best_match = ""
    best_match_score = 0

    # Find the best match using fuzzy string matching
    for question in destinations.keys():
        matcher = difflib.SequenceMatcher(None, user_tokens, question.split())
        match_score = matcher.ratio()
        if match_score > best_match_score:
            best_match_score = match_score
            best_match = question

    return best_match, destinations.get(best_match, 'what are you blabbering!!!')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_destination', methods=['POST'])
def get_destination():
    user_input = request.form['user_input']
    best_match, response = find_approximate_match(user_input)
    return render_template('index.html', response=response)

if __name__ == '__main__':
    app.run(debug=True)
